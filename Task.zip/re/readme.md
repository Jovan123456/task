simplest way 
Install xamp https://www.apachefriends.org/index.html ( or any service like this )
From Task.Zip copy "re" into C:\xamppp\htdocs ( or where is installed before )
localhost/re 
----------------------------------------------------------------
